from naming_server import server
server.port = 8521
server.launch()
